import logging
import time
from pathlib import Path

# ✅ ค่าคงที่ (ใช้ UPPER_CASE)
LOG_DIR = Path("output/logs")

def setup_logger(log_name: str = "shared_log") -> logging.Logger:
    """
    Setup and configure the logger.

    :param log_name: Prefix of the log file
    :return: Configured logger instance
    """
    # ✅ กำหนดวันที่และเวลาสำหรับไฟล์ log
    date_today = time.strftime("%Y-%m-%d")
    current_time = time.strftime("%Y-%m-%d-%H")

    # ✅ สร้างโฟลเดอร์ logs ตามวัน
    log_folder = LOG_DIR / date_today
    log_folder.mkdir(parents=True, exist_ok=True)

    log_filename = log_folder / f"{log_name}_{current_time}.log"

    # ✅ กำหนดรูปแบบการ log
    log_format = "%(asctime)s - %(levelname)s - %(message)s"
    date_format = "%Y-%m-%d %H:%M:%S"

    # ✅ ตั้งค่า logging
    logging.basicConfig(
        level=logging.INFO,
        format=log_format,
        datefmt=date_format,
        handlers=[
            logging.FileHandler(log_filename),  # ✅ Log ลงไฟล์
            logging.StreamHandler()  # ✅ Log ลง console ด้วย
        ]
    )

    return logging.getLogger(__name__)

# ✅ สร้าง logger instance
logger = setup_logger()

if __name__ == "__main__":
    logger.info("This is an information message.")
    logger.error("This is an error message.")
    logger.warning("This is a warning message.")
    logger.critical("This is a critical message.")
from enum import Enum

class TextColor(Enum):
    """Enum for ANSI text colors."""
    RED = "91"
    GREEN = "92"
    YELLOW = "93"
    MAGENTA = "95"
    PURPLE = "34"
    CYAN = "96"
    LIGHT_GRAY = "97"
    BLACK = "30"
    
    """Enum for ANSI highlight colors."""
    HIGHLIGHT_RED = "41"
    HIGHLIGHT_GREEN = "42"
    HIGHLIGHT_YELLOW = "43"
    HIGHLIGHT_MAGENTA = "45"
    HIGHLIGHT_PURPLE = "44"
    HIGHLIGHT_CYAN = "46"
    HIGHLIGHT_LIGHT_GRAY = "47"
    HIGHLIGHT_BLACK = "40"

class PrintColor:
    """Class for printing colored text in the terminal."""

    def _print_color(self, text: str, color_code: str) -> None:
        """Internal method to print colored text using ANSI escape codes."""
        print(f"\033[{color_code}m{text}\033[00m")

    def red(self, text: str) -> None:
        self._print_color(text, TextColor.RED.value)

    def green(self, text: str) -> None:
        self._print_color(text, TextColor.GREEN.value)

    def yellow(self, text: str) -> None:
        self._print_color(text, TextColor.YELLOW.value)

    def magenta(self, text: str) -> None:
        self._print_color(text, TextColor.MAGENTA.value)

    def purple(self, text: str) -> None:
        self._print_color(text, TextColor.PURPLE.value) 

    def cyan(self, text: str) -> None:
        self._print_color(text, TextColor.CYAN.value)

    def light_gray(self, text: str) -> None:
        self._print_color(text, TextColor.LIGHT_GRAY.value)

    def black(self, text: str) -> None:
        self._print_color(text, TextColor.BLACK.value)
        
    def highlight_red(self, text: str) -> None:
        self._print_color(text, TextColor.HIGHLIGHT_RED.value)
    
    def highlight_green(self, text: str) -> None:
        self._print_color(text, TextColor.HIGHLIGHT_GREEN.value)

    def highlight_yellow(self, text: str) -> None:
        self._print_color(text, TextColor.HIGHLIGHT_YELLOW.value)

    def highlight_magenta(self, text: str) -> None:
        self._print_color(text, TextColor.HIGHLIGHT_MAGENTA.value)
    
    def highlight_purple(self, text: str) -> None:
        self._print_color(text, TextColor.HIGHLIGHT_PURPLE.value)

    def highlight_cyan(self, text: str) -> None:
        self._print_color(text, TextColor.HIGHLIGHT_CYAN.value)

    def highlight_light_gray(self, text: str) -> None:
        self._print_color(text, TextColor.HIGHLIGHT_LIGHT_GRAY.value)

    def highlight_black(self, text: str) -> None:
        self._print_color(text, TextColor.HIGHLIGHT_BLACK.value)


# ✅ สร้าง instance ของ PrintColor
pr = PrintColor()

# ✅ ทดสอบสีทั้งหมด
if __name__ == "__main__":
    pr.red("This is a red text.")
    pr.green("This is a green text.")
    pr.yellow("This is a yellow text.")
    pr.magenta("This is a magenta text.")
    pr.purple("This is a purple text.")  
    pr.cyan("This is a cyan text.")
    pr.light_gray("This is a light gray text.")
    pr.black("This is a black text.")
    
    pr.highlight_red("This is a highlight red text.")
    pr.highlight_green("This is a highlight green text.")
    pr.highlight_yellow("This is a highlight yellow text.")
    pr.highlight_magenta("This is a highlight magenta text.")
    pr.highlight_purple("This is a highlight purple text.")
    pr.highlight_cyan("This is a highlight cyan text.")
    pr.highlight_light_gray("This is a highlight light gray text.")
    pr.highlight_black("This is a highlight black text.")
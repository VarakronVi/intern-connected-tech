import requests
from typing import Dict, Any, Optional

class APIRequest:
    """
    A class for making API requests with error handling.

    Methods:
        get(url, params, headers) -> dict
        post(url, data, headers, json) -> dict
        put(url, data, headers, json) -> dict
        delete(url, headers) -> dict
    """
    
    def __init__(self, 
                 base_url: str, 
                 timeout: int = 10):
        """
        Initialize APIRequest.

        :param base_url: The base URL of the API.
        :param timeout: Request timeout in seconds (default: 10s).
        """
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout

    def _handle_response(self, 
                         response: requests.Response) -> Dict[str, Any]:
        """Handle API response and return JSON or error message."""
        try:
            response.raise_for_status()
            return {"data": response.json(), "status_code": response.status_code}
        except requests.exceptions.HTTPError as http_err:
            return {"error": response.text, "status_code": response.status_code}
        except requests.exceptions.RequestException as req_err:
            return {"error": f"Request error: {req_err}"}
        except ValueError:
            return {"error": "Invalid JSON response"}

    def get(self, 
            endpoint: str, 
            params: Optional[Dict[str, Any]] = None, 
            headers: Optional[Dict[str, str]] = None) -> Dict[str, Any]:
        """Send a GET request."""
        url = f"{self.base_url}/{endpoint.lstrip('/')}"
        try:
            response = requests.get(url, 
                                    params=params, 
                                    headers=headers, 
                                    timeout=self.timeout)
            return self._handle_response(response)
        except requests.exceptions.RequestException as e:
            return {"error": f"GET request failed: {e}"}

    def post(self, 
             endpoint: str, 
             data: Optional[Dict[str, Any]] = None, 
             files: Optional[Dict[str, Any]] = None,
             json: Optional[Dict[str, Any]] = None, 
             headers: Optional[Dict[str, str]] = None) -> Dict[str, Any]:
        """Send a POST request."""
        url = f"{self.base_url}/{endpoint.lstrip('/')}"
        try:
            response = requests.post(url, 
                                     data=data, 
                                     files=files, 
                                     json=json, 
                                     headers=headers, 
                                     timeout=self.timeout)
            return self._handle_response(response)
        except requests.exceptions.RequestException as e:
            return {"error": f"POST request failed: {e}"}

    def put(self, 
            endpoint: str,
            data: Optional[Dict[str, Any]] = None, 
            json: Optional[Dict[str, Any]] = None, 
            headers: Optional[Dict[str, str]] = None) -> Dict[str, Any]:
        """Send a PUT request."""
        url = f"{self.base_url}/{endpoint.lstrip('/')}"
        try:
            response = requests.put(url, 
                                    data=data, 
                                    json=json, 
                                    headers=headers, 
                                    timeout=self.timeout)
            return self._handle_response(response)
        except requests.exceptions.RequestException as e:
            return {"error": f"PUT request failed: {e}"}

    def delete(self, 
               endpoint: str, 
               headers: Optional[Dict[str, str]] = None) -> Dict[str, Any]:
        """Send a DELETE request."""
        url = f"{self.base_url}/{endpoint.lstrip('/')}"
        try:
            response = requests.delete(url, 
                                       headers=headers, 
                                       timeout=self.timeout)
            return self._handle_response(response)
        except requests.exceptions.RequestException as e:
            return {"error": f"DELETE request failed: {e}"}
        
        
if __name__ == "__main__":
    # # ✅ ตั้งค่า API
    # api = APIRequest(base_url="https://jsonplaceholder.typicode.com")
    # # api = APIRequest(base_url="http://localhost:8081")

    # # ✅ ส่ง GET Request
    # response = api.get("posts/1")
    # print(response)

    # # ✅ ส่ง POST Request
    # post_data = {"title": "foo", 
    #              "body": "bar", 
    #              "userId": 1}
    # response = api.post("posts", json=post_data)
    # print(response)

    # # ✅ ส่ง PUT Request
    # update_data = {"title": "updated title"}
    # response = api.put("posts/1", json=update_data)
    # print(response)

    # # ✅ ส่ง DELETE Request
    # response = api.delete("posts/1")
    # print(response)
    
    
    files = {
        "objectID": (None, "202501211800010013"),  # ค่าข้อความ
        "timestamp": (None, "2024-09-28T15:37:58.666932+07:00"),  # ค่าข้อความ
        "stepIndex": (None, str(1)),  # ต้องแปลงเป็น string
        "file": ("image.jpg", None, "image/jpeg")  # ส่งไฟล์ภาพ
    }

    api = APIRequest(base_url="http://10.1.221.1:8081")
    
    response = api.post("/api/v1/monitor/step", files=files)
    print(response)
    print(response["status_code"])
    print(response["data"]["id"])
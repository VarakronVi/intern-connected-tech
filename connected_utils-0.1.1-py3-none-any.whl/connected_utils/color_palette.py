from dataclasses import dataclass
from typing import Tuple

def hex_to_rgb(hex_color: str) -> Tuple[int, int, int]:
    """Convert HEX color to RGB tuple."""
    hex_color = hex_color.lstrip("#")
    return tuple(int(hex_color[i:i+2], 16) for i in (0, 2, 4))

def hex_to_bgr(hex_color: str) -> Tuple[int, int, int]:
    """Convert HEX color to BGR tuple (for OpenCV)."""
    r, g, b = hex_to_rgb(hex_color)
    return (b, g, r)  # Swap R and B


@dataclass
class ColorPalette:
    """Color palette for UI components (HEX format)."""
    hover_brand_dark: str = "#005A5A"
    hover_brand_light: str = "#E4F9F9"
    hover_gray_light: str = "#F8FAFC"
    hover_gray_dark: str = "#E2E8F0"
    
    text_brand: str = "#00A2A2"
    text_black: str = "#334155"
    text_white: str = "#FFFFFF"
    text_gray_light: str = "#94A3B8"
    text_gray_dark: str = "#475569"
    
    bg_brand: str = "#00A2A2"
    bg_brand_dark: str = "#CCECEC"
    bg_brand_light: str = "#E4F9F9"
    bg_white: str = "#FFFFFF"
    bg_gray_light: str = "#F1F5F9"
    
    border_brand: str = "#00A2A2"
    border_gray_light: str = "#E2E8F0"
    
    icon_black: str = "#334155"


@dataclass
class ColorPaletteRGB:
    """Color palette in RGB format (converted from HEX)."""
    def __post_init__(self):
        color_palette = ColorPalette()
        for key, value in vars(color_palette).items():
            setattr(self, key, hex_to_rgb(value))


@dataclass
class ColorPaletteBGR:
    """Color palette in BGR format (converted from HEX)."""
    def __post_init__(self):
        color_palette = ColorPalette()
        for key, value in vars(color_palette).items():
            setattr(self, key, hex_to_bgr(value))


# ✅ สร้าง Instance ค่าคงที่
COLOR_PALETTE = ColorPalette()
COLOR_PALETTE_RGB = ColorPaletteRGB()
COLOR_PALETTE_BGR = ColorPaletteBGR()


if __name__ == "__main__":
    # ✅ ใช้งานค่าจาก COLOR_PALETTE
    print(COLOR_PALETTE.text_brand)  # "#00A2A2"
    print(COLOR_PALETTE.bg_gray_light)  # "#F1F5F9"

    # ✅ ใช้งานค่า BGR
    print(COLOR_PALETTE_BGR.border_brand)  # (162, 162, 0)

    # ✅ ใช้งานค่า RGB
    print(COLOR_PALETTE_RGB.border_brand)  # (0, 162, 162)